#!/usr/bin/env python3

google_api_key=''
google_cx_id=''
